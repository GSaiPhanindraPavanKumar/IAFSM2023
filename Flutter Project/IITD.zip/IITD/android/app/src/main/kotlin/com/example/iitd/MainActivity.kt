package com.example.iitd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
